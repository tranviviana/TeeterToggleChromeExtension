document.addEventListener('DOMContentLoaded', function () {
  //all the code is run ONLY when the popup.html is ready
  const searcher = document.getElementById('searcher');
  //button submitted?
  const searchQueryInput = document.getElementById('searchQuery');
  //the text in the search
  const websiteResults = document.getElementById('websiteresults');
  //what the html looks like


  // Function to handle saving the URL to storage
  function saveSearchQuery(query) {
    chrome.storage.local.set({ searchQuery: query });
  }


  //if popup is closed and then opened ... auto searchers based on the last input
  chrome.storage.local.get(['searchQuery'], function (result) {
    const storedSearchQuery = result.searchQuery;
    if (storedSearchQuery) {
      searchQueryInput.value = storedSearchQuery;
      websiteResults.src = `https://www.bing.com/search?q=${encodeURIComponent(storedSearchQuery)}`;
    }
  });

  // Function to perform the search
  function performSearch() {
    const searchQuery = searchQueryInput.value;
    if (searchQuery) {
      const encodedQuery = encodeURIComponent(searchQuery);
      const bingSearchUrl = `https://www.bing.com/search?q=${encodedQuery}`;

      // Set the iframe source to the Bing search URL
      websiteResults.src = bingSearchUrl;

      // Save the search query to storage
      saveSearchQuery(searchQuery);
    }
  }



  // on click or enter it will look through the text and perform the search query
  searcher.addEventListener('click', performSearch);
  searchQueryInput.addEventListener('keyup', function (event) {
    if (event.key === 'Enter') {
      performSearch();
    }
  });

});
